package FEATURE;
#!/usr/bin/perl
use strict;
use warnings;
use Cwd;
use File::Copy;
use File::Basename;


use TOOLKIT;


####################################################
#################   ��������   #####################
####################################################

sub readfasta {
	
	my $usage = "< fasta file > < hash reference >";
	my $infile = shift or die $usage;
	my $hash_seq = shift or die $usage;
	
	unless(-e $infile){
		print STDERR "Error:$infile not exists";
		die;
	}
	
	open IN, $infile || die;
	
	my $c=0;
	my $seqId;
	while (defined (my $line=<IN>)) {
		chomp($line);
		next if $line=~/^\s*$/;
		if ($line =~/^>/) {
			$line =~s/\s*$//g;	
			$line =~s/^\s*//g;	
			$seqId = substr($line,1);
			$c++;
		} else {
			$line =~s/\s*//g;
			$hash_seq->{$seqId}.=$line;
		}
	}
	close IN;
	
	return $c;
	
}


####################################################

sub k_mer {
	
	my $k = shift or die;
	my $seq = shift or die;
	my $hash_kmer = shift or die;
	

	if ( $k < 0 ){
		print STDERR "Error:$k < 0\n";
		die;
	}
		
	
	my @querys = ();
	my @bases = qw( A C G U );
	TOOLKIT::permutation(\@bases,\@querys,$k-1);
	
	
	my $lng = length($seq);
	$seq =~ tr/[acgtTun\.]/[ACGUUUNN]/;	
	
	for my $query ( @querys ) {
				
		my $n = 0;
		my $i = 0;
		while( $i < length($seq) ){		
			my $subseq = substr($seq,$i,$k);
			if ( $subseq eq $query ){
				$n++;
			}
			$i++;
		}
	
		unless(exists $hash_kmer->{$query}){
			$hash_kmer->{$query} = $n / ($lng - $k + 1) ;
		} else {
			print STDERR "Error:$query repeat\n";
			die;
		}
	}	
}



####################################################

sub kmer_composition_frequency {
	
	my $bin = shift or die;
	my $r_bin = shift or die;
	my $hash_input_seq = shift or die;
	my $hash_dist = shift or die;
	my $hash_base_compositions = shift or die;
	
	my $dist = 0;
	my $k_neighbour = 0;
	my $hash_potential;
	while (@_) {
		my $argument = shift @_;
		if ($argument=~/dist/i) {$dist=shift @_}
		if ($argument=~/k_neighbour/i) {$k_neighbour=shift @_}
		if ($argument=~/potential/i) {$hash_potential=shift @_}
	}
	
	
	
	my $score = 0;
	my %hash_seq = %{$hash_input_seq};
	for my $id ( keys %hash_seq ){
		
		my $seq = $hash_seq{$id};
		$seq =~ tr/[acgtTun\.]/[ACGUUUNN]/;	
		if ( $seq =~ /N/i ){
			print STDERR "Error:$seq include Ns\n";
			die;
		}
		
		# coordinate
		my %lattice = ();
		for(my $i = 0; $i < length($seq); $i++) {	
			my $base = substr($seq,$i,1);
			$lattice{$i}{"x"} = $i;
			$lattice{$i}{"base"} = $base;
		}
		
		
		# the number of pair (i,j) at the distance r		
		for(my $i = 0; $i < length($seq) - $dist - $k_neighbour - 1; $i++) {
			for(my $j = $i + $dist + 1; $j < length($seq) - $k_neighbour; $j++) {
				
				my $r = abs($lattice{$i}{"x"}-$lattice{$j}{"x"});				
				my $b = int( $r / $r_bin );
				if ( $b > $bin ){
					$b = $bin;
				}
					

				my $base_i = "";
				my $base_j = "";
				for my $k ( 0 .. $k_neighbour ){
					$base_i .= $lattice{$i+$k}{"base"};
				}
				for my $k ( 0 .. $k_neighbour ){
					$base_j .= $lattice{$j+$k}{"base"};
				}	
					
				my $base_ij = "$base_i.$base_j";
				$hash_base_compositions->{$base_ij} = 1;		
				
				if( defined $hash_potential ){
					
					if ( exists $hash_potential->{$base_ij}{$b} ){
						my $u = $hash_potential->{$base_ij}{$b};
						$score += $u;
					} 
					
				}else{
					
					unless(exists $hash_dist->{$base_ij}{$b}){
						$hash_dist->{$base_ij}{$b} = 1;
					} else {
						$hash_dist->{$base_ij}{$b}++;
					}	
				}
				
			}
		}
	}
	
	return $score;
}
	


####################################################

sub statistical_potentials {
	
	my $bin = shift or die;
	my $r_bin = shift or die;
	my $positive_fasta = shift or die;
	my $negative_fasta = shift or die;
	my $hash_potentials = shift or die;
	
	
	
	my $dist = 0;
	my $k_neighbour = 0;
	while (@_) {
		my $argument = shift @_;
		if ($argument=~/dist/i) {$dist=shift @_}
		if ($argument=~/k_neighbour/i) {$k_neighbour=shift @_}
	}
	
	
	unless(-e $positive_fasta){
		print STDERR "Error:$positive_fasta not exists\n";
		die;
	}
	
	unless(-e $negative_fasta){
		print STDERR "Error:$negative_fasta not exists\n";
		die;
	}
	
	
	# ================= Positive =========================
	
	
	my %hash_seq = ();
	&readfasta($positive_fasta,\%hash_seq);
	
	my %hash_pos_dist = ();
	my %hash_base_compositions = ();
	&kmer_composition_frequency($bin,$r_bin,\%hash_seq,\%hash_pos_dist,
	\%hash_base_compositions,'k_neighbour'=>$k_neighbour,'dist'=>$dist);
	
	
	
	# ================= Negative =========================
	
	%hash_seq = ();
	&readfasta($negative_fasta,\%hash_seq);
	
	my %hash_neg_dist = ();
	&kmer_composition_frequency($bin,$r_bin,\%hash_seq,\%hash_neg_dist,
	\%hash_base_compositions,'k_neighbour'=>$k_neighbour,'dist'=>$dist);
	

	
	
	# ==========================================
	
	my $epsilon = 0.00001;
	for my $base_ij ( sort keys %hash_base_compositions ){
	for my $b ( 0 .. $bin ){
		
		my $numerator = 1;
		if (exists $hash_pos_dist{$base_ij}{$b}){
			$numerator = $hash_pos_dist{$base_ij}{$b};
		}
		
		my $denominator = 1;
		if (exists $hash_neg_dist{$base_ij}{$b}){
			$denominator = $hash_neg_dist{$base_ij}{$b};
		}
		
		if( ($numerator > 1) or ($denominator > 1) ){
			my $r = -1 * log ( $numerator / $denominator );
			$r = TOOLKIT::round($r,6);
			
			if ( abs($r) >= $epsilon ){
				unless(exists $hash_potentials->{$base_ij}{$b}){
					$hash_potentials->{$base_ij}{$b} = $r;
				} else {
					print STDERR "Error:($base_ij,$b) repeat\n";
					die;
				}
			}
		}
		
	}}
	
	# ==========================================	
}



####################################################

sub energy_score {
	
	my $bin = shift or die;
	my $r_bin = shift or die;
	my $seq = shift or die;
	my $hash_potential = shift or die;


	my $dist = 0;
	my $k_neighbour = 0;
	while (@_) {
		my $argument = shift @_;
		if ($argument=~/dist/i) {$dist=shift @_}
		if ($argument=~/k_neighbour/i) {$k_neighbour=shift @_}
	}


	$seq =~ tr/[acgtTun\.]/[ACGUUUNN]/;	
	if ( $seq =~ /N/i ){
		print STDERR "Error:$seq include Ns\n";
		die;
	}
	
	my %hash_seq = ();
	$hash_seq{"id"} = $seq;
	
	my %hash_tmp1 = ();
	my %hash_tmp2 = ();
	my $score = &kmer_composition_frequency($bin,$r_bin,\%hash_seq,\%hash_tmp1,\%hash_tmp2,
	'k_neighbour'=>$k_neighbour,'dist'=>$dist,'potential'=>$hash_potential);
	
	return $score;

}
	
	
####################################################

sub pssm {
	
	my $fastaFile   = shift or die;
	my $hash_pssm   = shift or die;
	my $window_size = shift or die;
	
	
	my $is_tail = 0;
	while (@_) {
		my $argument = shift @_;	
		if ($argument=~/tail/i) {$is_tail=shift @_}
	}
	
	
	
	unless(-e $fastaFile){
		print STDERR "Error:$fastaFile not exists\n";
		die;
	}

	my %hash_seq = ();
	&readfasta($fastaFile,\%hash_seq);
	
	
	my %hash_base = ();
	my @bases = qw( A C G U );
	
	for my $id ( sort keys %hash_seq ){
		
		my $seq = $hash_seq{$id};
		$seq =~ tr/[acgtuTn\.]/[ACGUUUNN]/;		
		
		my $subseq = "";
		if( $is_tail ){
			$subseq = substr($seq,-$window_size);
			$subseq = reverse($subseq);
		}else{
			$subseq = substr($seq,0,$window_size);
		}
			
		for my $base ( @bases ){
				
			my %hash_pos = ();
			TOOLKIT::matchPattern(0,$base,$subseq,\%hash_pos);
			
			for my $p ( sort {$a<=>$b} keys %hash_pos ){
				$p++;
				unless(exists $hash_base{$p}{$base}){
					$hash_base{$p}{$base} = 1;
				} else {
					$hash_base{$p}{$base}++;
				}
			}
		}
	}
	
	
	my %hash_tot = ();
	for my $p ( sort {$a<=>$b} keys %hash_base ){
		my $sum = 0;
		for my $base ( @bases ){
			if (exists $hash_base{$p}{$base}){
				$sum += $hash_base{$p}{$base};
			}
		}
		$hash_tot{$p} = $sum;
	}
	
	
	for my $p ( sort {$a<=>$b} keys %hash_base ){
		for my $base ( @bases ){
			my $t = 0;
			if (exists $hash_base{$p}{$base}){				
				$t = TOOLKIT::round($hash_base{$p}{$base}/$hash_tot{$p},6);
			}
			
			
			my $key = $p."_".$base;
			$key = "-$key" if $is_tail;
			
			
			$hash_pssm->{$key} = $t;
		}
	}
	
}
				
	
	
####################################################

sub pssm_score {
	
	my $seq = shift or die;
	my $hash_pssm_pos = shift or die;
	my $hash_pssm_neg = shift or die;
	my $window_size = shift or die;
	my $hash_score = shift or die;
	
	my $is_tail = 0;
	while (@_) {
		my $argument = shift @_;	
		if ($argument=~/tail/i) {$is_tail=shift @_}
	}
	
	
	$seq =~ tr/[acgtTun\.]/[ACGUUUNN]/;	
	if ( $seq =~ /N/i ){
		print STDERR "Error:$seq include Ns\n";
		die;
	}
	

	my $subseq = "";
	if( $is_tail ){
		$subseq = substr($seq,-$window_size);
		$subseq = reverse($subseq);
	}else{
		$subseq = substr($seq,0,$window_size);
	}
	
	
	my $pos_score = 1;
	my $neg_score = 1;
	
	for(my $i = 0; $i <= length($subseq)-1; $i++) {
		my $p = $i + 1;
		my $base = substr($subseq,$i,1);
		
		
		my $key = $p."_".$base;
		$key = "-$key" if $is_tail;
		
				
		if( (exists $hash_pssm_pos->{$key}) and (exists $hash_pssm_neg->{$key}) ){
			$hash_score->{$key} = TOOLKIT::logN($hash_pssm_pos->{$key}/$hash_pssm_neg->{$key},2);
		}else{
			print STDERR "Error:($key) not exists\n";
			die;
		}
		
		$pos_score *= $hash_pssm_pos->{$key};
		$neg_score *= $hash_pssm_neg->{$key};
	
	}
	
	
	my $score = 0;
	if ($pos_score > 0 && $neg_score > 0 ){
		my $R = $pos_score / $neg_score;
		$score = TOOLKIT::logN($R,2);
	}
	
	
	# ����û�е�
	for my $key ( sort keys %$hash_pssm_pos ){
		unless(exists $hash_score->{$key}){
			$hash_score->{$key} = 0;
		}
	}
	
	
	return $score;
	
}



####################################################
#################   ��������   #####################
####################################################

sub F_score {
	
	my $infile_feature = shift or die;
	my $hash_fscore = shift or die;
	

	unless(-e $infile_feature){
		print STDERR "Error:$infile_feature not exists\n";
		die;
	}
	
	
	my %hash_row = ();
	my @cols = TOOLKIT::toMatrix($infile_feature,\%hash_row);
	
	
	my @rows = ();
	for my $row ( sort {$a cmp $b} keys %hash_row ){
		if ( $row !~/^\bname\b/i ){
			push(@rows,$row);
		}
	}
	
	
	my $feature_num = 0;
	for my $col ( 1 .. $#cols - 1 ){
	
		my $whole_sum 	 = 0;
		my $positive_sum = 0;
		my $negative_sum = 0;
		my $positive_num = 0;
		my $negative_num = 0;
		$feature_num++;
		
		for my $row ( @rows ){
			
			my $v = $hash_row{$row}{ $cols[$col] };
			my $label = $hash_row{$row}{ $cols[$#cols] };
			
			$whole_sum += $v;
			if ( $label eq "positive" ){		
				$positive_sum += $v;
				$positive_num++;		
			} elsif ( $label eq "negative" ){		
				$negative_sum += $v;
				$negative_num++;	
			} else {
				print STDERR "Error:($row,$cols[$col],$v)\n";
				die;
			}
		}
		
		my $whole_av 	= $whole_sum / ($positive_num + $negative_num);
		my $positive_av = $positive_sum / $positive_num;
		my $negative_av = $negative_sum / $negative_num;
		
		my $numerator = ( $positive_av - $whole_av ) * ( $positive_av - $whole_av );
		$numerator   += ( $negative_av - $whole_av ) * ( $negative_av - $whole_av );
		
		my $positive_variance_sum = 0;
		my $negative_variance_sum = 0;

		for my $row ( @rows ){
			
			my $v = $hash_row{$row}{ $cols[$col] };
			my $label = $hash_row{$row}{ $cols[$#cols] };
			
			if ( $label eq "positive" ){			
				my $t = ( $v - $positive_av ) * ( $v - $positive_av );
				$positive_variance_sum += $t;	
			} elsif ( $label eq "negative" ){		
				my $t = ( $v - $negative_av ) * ( $v - $negative_av );
				$negative_variance_sum += $t;	
			} else {
				print STDERR "Error:($row,$cols[$col],$v)\n";
				die;
			}
		}
		
		my $f_score = 0;	
		if ( $positive_num > 1 && $negative_num > 1 ){
			my $denominator = $positive_variance_sum / ( $positive_num - 1 );
			$denominator   += $negative_variance_sum / ( $negative_num - 1 );
			if ( $denominator ){
				$f_score = $numerator / $denominator;
			}
		}
		
		$hash_fscore->{$cols[$col]} = $f_score;
		
	}
	
	return $feature_num;
	
}



####################################################
#################   ��ȡ����   #####################
####################################################

sub feature_extraction {
	
	my $fasta = shift or die;
	my $hash_parameter = shift or die;
	my $hash_argument = shift or die;
	local *FEATURE = shift or die;

	
	my $label;
	my $title_flag = 0;
	while (@_) {
		my $argument = shift @_;	
		if ($argument=~/label/i) {$label=shift @_}
		if ($argument=~/title/i) {$title_flag=shift @_}
	}
	
	
	# ************************************** #
	# ��ò���
	# ************************************** #
	
	
	# parameters for PSSM features 
	my $is_pssm = $hash_parameter->{is_pssm};
	my $window_size = $hash_parameter->{window_size};

	
	# parameters for k-mer featurs
	my $is_kmer = $hash_parameter->{is_kmer};
	

	# parameters for statistic potential features
	my $rbin = $hash_parameter->{rbin};
	my $nbin = $hash_parameter->{nbin};
	my $dist = $hash_parameter->{dist};
	my $is_potential_seq = $hash_parameter->{is_potential_seq};
	
	
	# array & hash reference
	my $k_mers = $hash_argument->{k_mers};
	my $adjacents = $hash_argument->{adjacents};
	my $hash_potential_seq = $hash_argument->{hash_potential_seq};
	my $hash_pssm_positive = $hash_argument->{hash_pssm_positive};
	my $hash_pssm_negative = $hash_argument->{hash_pssm_negative};

	
	

	##########################################


	my %hash_seq = ();
	&readfasta($fasta,\%hash_seq);
	

	my $num_featrure  = 0;	
	my %hash_check_id = ();
	for my $id ( sort keys %hash_seq ){
	
		my $seq = $hash_seq{$id};
		$seq =~ tr/[acgtTun\.]/[ACGUUUNN]/;	
		if( not ($seq =~/^([A|C|G|U|N]+)$/) ){
			next;
		}
		
		
		my $new_id = $id;	
		$new_id =~ s/^\s*//g;
		$new_id =~ s/\s*$//g;
		if($new_id =~ /(\S+)/){
			$new_id = $1;
		}
		
		unless(exists $hash_check_id{$new_id}){
			$hash_check_id{$new_id} = 1;
		} else {
			print STDERR "Error:$new_id repeat\n";
			die;
		}
		
		
		my $n = 0;
		my $str = $new_id;		
		my %hash_feature = ();
		
		
		# ************* sequence feature ************** #

	
		# k-mer feature	
		if ( $is_kmer ) {
			for my $k_mer_v ( @$k_mers ){
				my %hash_kmer = ();			
				&k_mer($k_mer_v,$seq,\%hash_kmer);			
				for my $k_mer ( sort keys %hash_kmer ){
					my $t = TOOLKIT::round($hash_kmer{$k_mer},6);
					$str .= "\t$t";
					$hash_feature{$n} = $k_mer;
					$n++;
				}				
			}
		}

		
		# energy score of sequence chain
		if( $is_potential_seq )	{
			for my $k ( @$adjacents ){	
				my $energy_score = &energy_score($nbin,$rbin,$seq,
				$hash_potential_seq,'dist'=>$dist,'k_neighbour'=>$k);
				
				$energy_score = TOOLKIT::round($energy_score,6);
				$str .= "\t$energy_score";
				$hash_feature{$n} = "$k-energy_score";
				$n++;
			}
		}
		
		
		# ************* PSSM feature ************** #
		
		if( $is_pssm ){
			my %hash_score = ();
			my $score_head = &pssm_score($seq,$hash_pssm_positive,$hash_pssm_negative,
			$window_size,\%hash_score);
			
			my $score_tail = &pssm_score($seq,$hash_pssm_positive,$hash_pssm_negative,
			$window_size,\%hash_score,'tail'=>1);
			
			for my $t ( sort {$a cmp $b} keys %hash_score ){
				my $v = TOOLKIT::round($hash_score{$t},6);
				$str .= "\t$v";
				$hash_feature{$n} = "$t";
				$n++;
			}
		}

		
		# ***************** OUTPUT *************** #
		
		if ( $title_flag ){
			my $title = "Name";
			my %hash_tmp = ();
			for my $f ( sort {$a <=> $b} keys %hash_feature ){
				my $feature = $hash_feature{$f};
				$title .= "\t$feature";
				unless(exists $hash_tmp{$feature}){
					$hash_tmp{$feature} = 1;
				} else {
					print STDERR "Error:($f,$feature) repeat\n";
					die;
				}
			}
			
			if(defined $label){
				print FEATURE "$title\ttype\n";
			}else{
				print FEATURE "$title\n";
			}
			
			$title_flag = 0;
		}
		
		
		# ***************************************** #
		
		if(defined $label){
			print FEATURE "$str\t$label\n";
		}else{
			print FEATURE "$str\n";
		}
		
		unless( $num_featrure ){
			$num_featrure = $n;
		} elsif ( $num_featrure != $n ){
			print STDERR "Error:lack feature ($id\n$seq\n)\n";
			die;
		}
		
	}
	

	return $num_featrure;
	
}


####################################################
1;


