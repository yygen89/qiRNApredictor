#!/usr/bin/perl
use strict;
use warnings;
use Cwd;
use File::Copy;
use File::Path;
use File::Basename;
use Getopt::Long  qw(:config bundling);



use TOOLKIT;
use FEATURE;
use RandomForest;



	
# parameters	
my $is_kmer = 0;
my $is_pssm = 1;
my $is_potential_seq = 0;
my $nbin = 6;
my $rbin = 2;
my $k_mer = 3;
my $dist = 0;
my $adjacent = 8;
my $cv = 4;
my $round_num = 5;
my $window_size = 10;
my $positive_fasta;
my $negative_fasta;
my $test_fasta;
my $dir;
my $help;


GetOptions( 	
	"help|h!"			=> \$help,
	"dir|D=s"			=> \$dir,
	"posFasta|P=s"		=> \$positive_fasta,
	"negFasta|N=s"		=> \$negative_fasta,
	"T=s"				=> \$test_fasta,
);




########################################
# start 
########################################


if ( $help ) {
	&usage(); exit;
}

if( defined $positive_fasta ){
	$positive_fasta = TOOLKIT::getAbsPath($positive_fasta);
}else{
	&usage(); exit;
}

if( defined $negative_fasta ){
	$negative_fasta = TOOLKIT::getAbsPath($negative_fasta);	
}else{
	&usage(); exit;
}

if( defined $test_fasta ){
	$test_fasta = TOOLKIT::getAbsPath($test_fasta);	
}else{
	&usage(); exit;
}


my @k_mers = ();
for my $r ( 1 .. $k_mer ){
	push(@k_mers,$r);
}

my @adjacents = ();
for my $r ( 0 .. $adjacent ){
	push(@adjacents,$r);
}

	
my $current_dir = getcwd;
unless( defined $dir ){
	$dir = $current_dir;
} else {
	$dir = TOOLKIT::getAbsPath($dir);
}
mkdir($dir);


my $tmp_dir = "$dir/tmp_dir";
mkdir($tmp_dir);




#############################################################
# Save all parameters
#############################################################

my %hash_parameter = ();

# parameters for CV
$hash_parameter{cv} = $cv;
$hash_parameter{round_num} = $round_num;


# parameters for PSSM features 
$hash_parameter{is_pssm} = $is_pssm;
$hash_parameter{window_size} = $window_size;


# parameters for k-mer featurs
$hash_parameter{is_kmer} = $is_kmer;
$hash_parameter{k_mer}   = $k_mer;



# parameters for statistic potential features
$hash_parameter{rbin} = $rbin;
$hash_parameter{nbin} = $nbin;
$hash_parameter{dist} = $dist;
$hash_parameter{adjacent} = $adjacent;
$hash_parameter{is_potential_seq} = $is_potential_seq;



# save parameters into file
my $parameter_file = "$tmp_dir/parameter.txt";
open OUT,">$parameter_file" or die;
for my $parameter ( sort keys %hash_parameter ){
	my $value = $hash_parameter{$parameter};
	print OUT "$parameter#$value\n";
}
close OUT;




	
#############################################################
# Calculate statistical potentials
#############################################################


my %hash_potential_seq = ();
if( $is_potential_seq ){
	for my $k ( @adjacents ){
		FEATURE::statistical_potentials($nbin,$rbin,$positive_fasta,$negative_fasta,
		\%hash_potential_seq,'k_neighbour'=>$k,'dist'=>$dist);
	}

	my $seq_potential_model = "$tmp_dir/seq_potential.txt";
	open POTENTIAL,">$seq_potential_model" or die;
	
	for my $base_ij ( sort keys %hash_potential_seq ){
	for my $nbin ( sort {$a<=>$b} keys %{$hash_potential_seq{$base_ij}} ){
		my $value = $hash_potential_seq{$base_ij}{$nbin};
		print POTENTIAL "$base_ij\t$nbin\t$value\n";
	}}
	close POTENTIAL;
}


	
#############################################################
# Calcuate PSSM
#############################################################


my %hash_pssm_positive = ();
my %hash_pssm_negative = ();
if( $is_pssm ){
	FEATURE::pssm($positive_fasta,\%hash_pssm_positive,$window_size);
	FEATURE::pssm($positive_fasta,\%hash_pssm_positive,$window_size,'tail'=>1);
	FEATURE::pssm($negative_fasta,\%hash_pssm_negative,$window_size);
	FEATURE::pssm($negative_fasta,\%hash_pssm_negative,$window_size,'tail'=>1);
}





#############################################################
# Feature extraction
#############################################################


# array & hash reference
my %hash_argument = ();
$hash_argument{k_mers} = \@k_mers;
$hash_argument{adjacents} = \@adjacents;
$hash_argument{hash_potential_seq} = \%hash_potential_seq;
$hash_argument{hash_pssm_positive} = \%hash_pssm_positive;
$hash_argument{hash_pssm_negative} = \%hash_pssm_negative;


my $input_feature = "$tmp_dir/feature.txt";
open FEATURE,">$input_feature" or die;
my $featrure_num = FEATURE::feature_extraction($positive_fasta,
\%hash_parameter,\%hash_argument,\*FEATURE,'title'=>1,'label'=>"positive");


FEATURE::feature_extraction($negative_fasta,
\%hash_parameter,\%hash_argument,\*FEATURE,'label'=>"negative");
close FEATURE;





#############################################################
# Training
#############################################################



my $model_file = "$tmp_dir/model.Rdata";
RandomForest::training($input_feature,$model_file,$tmp_dir);








# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ #
# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ #
# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ #







#############################################################
# Feature extraction for predicted sequences
#############################################################




my $input_feature_predict = "$tmp_dir/feature.txt";
open FEATURE,">$input_feature_predict" or die;
FEATURE::feature_extraction($test_fasta,\%hash_parameter,
\%hash_argument,\*FEATURE,'title'=>1);
close FEATURE;





#############################################################
# Prediction
#############################################################


my $result_file = "$dir/result.txt";
RandomForest::predict($input_feature_predict,$model_file,$result_file,$tmp_dir);






########################################
# End 
########################################


rmtree($tmp_dir);


unlink("$current_dir/training.Rout") if -e "$current_dir/training.Rout";
unlink("$current_dir/predict.Rout") if -e "$current_dir/predict.Rout";
unlink("$current_dir/tuneRF.Rout") if -e "$current_dir/tuneRF.Rout";

print "\n\n============== End ============\n\n";






# =============================
# Author: Yuangen Yao
# Date: 2013-2-20
# =============================

sub usage {
	
my $usage = << "USAGE";

Program: $0
Contact: Yao Yuangen <yygen89\@163.com>

Usage:

	+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 
		
	Options:
	
	-D [dir] : the result directory
	-N [file} : fasta file containing negative sequences
	-P [file] : fasta file containing positive sequences
	-T [file] : fasta file containing sequences to be predicted
	-h : help
	
	+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 
	
	$0 [options] -P <postive fasta> -N <negative fasta> -T <test fasta>

	+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 

USAGE
print $usage;

}
	

